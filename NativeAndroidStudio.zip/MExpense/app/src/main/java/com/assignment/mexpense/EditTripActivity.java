package com.assignment.mexpense;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.assignment.mexpense.datamodel.Trip;
import com.assignment.mexpense.repository.TripRepository;

public class EditTripActivity extends AppCompatActivity {

    private EditText editTextTripName, editTextDestination, editTextStartDate, editTextEndDate, editTextTransport, editTextAccommodation, editTextDescription;
    private Button buttonSave;

    private TripRepository tripRepository;
    private long tripId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_trip);

        tripRepository = new TripRepository(this);

        editTextTripName = findViewById(R.id.editTextTripName);
        editTextDestination = findViewById(R.id.editTextDestination);
        editTextStartDate = findViewById(R.id.editTextStartDate);
        editTextEndDate = findViewById(R.id.editTextEndDate);
        editTextTransport = findViewById(R.id.editTextTransport);
        editTextAccommodation = findViewById(R.id.editTextAccommodation);
        editTextDescription = findViewById(R.id.editTextDescription);

        buttonSave = findViewById(R.id.buttonSave);

        // Get the tripId from the intent
        tripId = getIntent().getLongExtra("tripId", -1);

        // Load the trip details using the tripId
        loadTripDetails(tripId);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTripDetails();
            }
        });
    }

    private void loadTripDetails(long tripId) {
        Trip trip = tripRepository.getTripById(tripId);
        if (trip != null) {
            editTextTripName.setText(trip.getTripName());
            editTextDestination.setText(trip.getDestination());
            editTextStartDate.setText(trip.getStartDate());
            editTextEndDate.setText(trip.getEndDate());
            editTextTransport.setText(trip.getTransport());
            editTextAccommodation.setText(trip.getAccommodation());
            editTextDescription.setText(trip.getDescription());
        } else {
            Toast.makeText(this, "Trip not found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void saveTripDetails() {
        String tripName = editTextTripName.getText().toString();
        String destination = editTextDestination.getText().toString();
        String startDate = editTextStartDate.getText().toString();
        String endDate = editTextEndDate.getText().toString();
        String transport = editTextTransport.getText().toString();
        String accommodation = editTextAccommodation.getText().toString();
        String description = editTextDescription.getText().toString();

        boolean isValid = true;

        if (tripName.isEmpty()) {
            editTextTripName.setError("Trip name is required");
            isValid = false;
        }

        if (destination.isEmpty()) {
            editTextDestination.setError("Destination is required");
            isValid = false;
        }

        if (startDate.isEmpty()) {
            editTextStartDate.setError("Start date is required");
            isValid = false;
        }

        if (endDate.isEmpty()) {
            editTextEndDate.setError("End date is required");
            isValid = false;
        }

        if (transport.isEmpty()) {
            editTextTransport.setError("Mode of transport is required");
            isValid = false;
        }

        if (accommodation.isEmpty()) {
            editTextAccommodation.setError("Accommodation details are required");
            isValid = false;
        }

        if (isValid) {
            Trip trip = new Trip(tripId, tripName, destination, startDate, endDate, transport, accommodation, description);
            tripRepository.updateTrip(trip);
            Toast.makeText(this, "Trip details updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please fill in all required fields", Toast.LENGTH_SHORT).show();
        }
    }
}
