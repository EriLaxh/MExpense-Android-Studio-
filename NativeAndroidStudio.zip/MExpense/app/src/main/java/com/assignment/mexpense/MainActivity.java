package com.assignment.mexpense;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button buttonEnterTripDetails;
    private Button buttonViewTrips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonEnterTripDetails = findViewById(R.id.buttonEnterTripDetails);
        buttonViewTrips = findViewById(R.id.buttonViewTrips);

        buttonEnterTripDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEnterTripDetailsActivity();
            }
        });

        buttonViewTrips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTripListActivity();
            }
        });
    }

    private void openEnterTripDetailsActivity() {
        Intent intent = new Intent(this, EnterTripDetailsActivity.class);
        startActivity(intent);
    }

    private void openTripListActivity() {
        Intent intent = new Intent(this, TripListActivity.class);
        startActivity(intent);
    }
}
