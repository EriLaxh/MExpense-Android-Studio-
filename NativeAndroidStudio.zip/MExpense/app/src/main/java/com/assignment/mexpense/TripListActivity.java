package com.assignment.mexpense;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.assignment.mexpense.adapter.TripListAdapter;
import com.assignment.mexpense.datamodel.Trip;
import com.assignment.mexpense.repository.TripRepository;

import java.util.ArrayList;
import java.util.List;

public class TripListActivity extends AppCompatActivity implements TripListAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private List<Trip> tripList;
    private TripListAdapter adapter;
    private TripRepository tripRepository;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_list);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tripList = new ArrayList<>();
        adapter = new TripListAdapter(tripList, this);
        recyclerView.setAdapter(adapter);

        // Initialize TripRepository
        tripRepository = new TripRepository(this);

        // Load all trips initially
        loadTrips("");

        // Initialize Delete All button
        Button buttonDeleteAll = findViewById(R.id.buttonDeleteAll);
        buttonDeleteAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAllTrips();
            }
        });
    }

    @Override
    public void onItemClick(Trip trip) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit or Delete Trip");
        builder.setMessage("Choose an action for trip: " + trip.getTripName());
        builder.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Start EditTripActivity with the selected trip's id
                Intent intent = new Intent(TripListActivity.this, EditTripActivity.class);
                intent.putExtra("tripId", trip.getId());
                startActivity(intent);
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteTrip(trip);
                dialog.dismiss();
            }
        });
        builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void loadTrips(final String query) {
        new AsyncTask<Void, Void, List<Trip>>() {
            @Override
            protected List<Trip> doInBackground(Void... voids) {
                if (query.isEmpty()) {
                    return tripRepository.getAllTrips();
                } else {
                    return tripRepository.getTripsByName(query);
                }
            }

            @Override
            protected void onPostExecute(List<Trip> trips) {
                super.onPostExecute(trips);
                tripList.clear();
                tripList.addAll(trips);
                adapter.notifyDataSetChanged();
            }
        }.execute();
    }

    private void deleteTrip(Trip trip) {
        tripRepository.deleteTrip(trip);
        loadTrips("");
    }

    private void deleteAllTrips() {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                tripRepository.deleteAllTrips();
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                loadTrips("");
            }
        }.execute();
    }
}
