package com.assignment.mexpense.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.assignment.mexpense.datamodel.Trip;

import java.util.List;

@Dao
public interface TripDao {

    @Update
    void update(Trip trip);

    @Insert
    void insert(Trip trip);

    @Delete
    void delete(Trip trip);

    @Query("DELETE FROM trips")
    void deleteAllTrips();

    @Query("SELECT * FROM trips WHERE id = :id")
    Trip getTripById(long id);

    @Query("SELECT * FROM trips ORDER BY id DESC")
    List<Trip> getAllTrips();

    @Query("SELECT * FROM trips WHERE tripName LIKE :name ORDER BY id DESC")
    List<Trip> getTripsByName(String name);
}