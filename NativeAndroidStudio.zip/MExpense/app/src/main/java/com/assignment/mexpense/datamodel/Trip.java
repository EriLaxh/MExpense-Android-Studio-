package com.assignment.mexpense.datamodel;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

@Entity(tableName = "trips")
public class Trip {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String tripName;
    private String destination;
    private String startDate;
    private String endDate;
    private String transport;
    private String accommodation;
    private String description;
    private long durationDays; // Duration of the trip in days
    private long durationNights; // Duration of the trip in nights

    public Trip() {
        // Default constructor
    }

    public Trip(String tripName, String destination, String startDate, String endDate, String transport, String accommodation, String description) {
        this.tripName = tripName;
        this.destination = destination;
        this.startDate = startDate;
        this.endDate = endDate;
        this.transport = transport;
        this.accommodation = accommodation;
        this.description = description;
        calculateDuration(startDate, endDate);
    }

    // Getter and setter methods
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    public String getAccommodation() {
        return accommodation;
    }

    public void setAccommodation(String accommodation) {
        this.accommodation = accommodation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getDurationDays() {
        return durationDays;
    }

    public void setDurationDays(long durationDays) {
        this.durationDays = durationDays;
    }

    public long getDurationNights() {
        return durationNights;
    }

    public void setDurationNights(long durationNights) {
        this.durationNights = durationNights;
    }

    private void calculateDuration(String startDate, String endDate) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        try {
            Date start = format.parse(startDate);
            Date end = format.parse(endDate);
            long diffInMillies = Math.abs(end.getTime() - start.getTime());
            long diffInDays = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

            this.durationDays = diffInDays;

            // Calculate number of nights
            Calendar startCalendar = Calendar.getInstance();
            startCalendar.setTime(start);
            Calendar endCalendar = Calendar.getInstance();
            endCalendar.setTime(end);

            int startDayOfYear = startCalendar.get(Calendar.DAY_OF_YEAR);
            int endDayOfYear = endCalendar.get(Calendar.DAY_OF_YEAR);
            int diffInDaysOfYear = endDayOfYear - startDayOfYear;

            int year = endCalendar.get(Calendar.YEAR);
            if (startDayOfYear > endDayOfYear) {
                year--;
                endCalendar.add(Calendar.YEAR, 1);
                endDayOfYear = endCalendar.get(Calendar.DAY_OF_YEAR);
                diffInDaysOfYear = endDayOfYear - startDayOfYear;
            }

            this.durationNights = diffInDaysOfYear;

        } catch (ParseException e) {
            e.printStackTrace();
            this.durationDays = 0;
            this.durationNights = 0;
        }
    }
}
