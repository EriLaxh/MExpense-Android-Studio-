package com.assignment.mexpense.repository;

import android.content.Context;
import android.os.AsyncTask;

import com.assignment.mexpense.database.AppDatabase;
import com.assignment.mexpense.datamodel.Trip;
import com.assignment.mexpense.database.TripDao;

import java.util.List;

public class TripRepository {

    private TripDao tripDao;

    // Constructor to initialize the TripDao
    public TripRepository(Context context) {
        AppDatabase database = AppDatabase.getInstance(context);
        tripDao = database.tripDao();
    }

    // Method to insert a trip into the database
    public void insertTrip(Trip trip) {
        new InsertTripAsyncTask(tripDao).execute(trip);
    }

    // Method to get all trips from the database
    public List<Trip> getAllTrips() {
        return tripDao.getAllTrips();
    }

    // Method to get trips by name from the database
    public List<Trip> getTripsByName(String tripName) {
        return tripDao.getTripsByName(tripName);
    }

    // Method to get a trip by ID from the database
    public Trip getTripById(int id) {
        return tripDao.getTripById(id);
    }

    // Method to delete a trip from the database
    public void deleteTrip(Trip trip) {
        new DeleteTripAsyncTask(tripDao, trip).execute();
    }

    // Method to delete all trips from the database
    public void deleteAllTrips() {
        new DeleteTripAsyncTask(tripDao, null).execute();
    }

    // AsyncTask to insert a trip into the database
    private static class InsertTripAsyncTask extends AsyncTask<Trip, Void, Void> {

        private TripDao tripDao;

        public InsertTripAsyncTask(TripDao tripDao) {
            this.tripDao = tripDao;
        }

        @Override
        protected Void doInBackground(Trip... trips) {
            tripDao.insert(trips[0]);
            return null;
        }
    }

    // AsyncTask to delete a trip from the database
    private static class DeleteTripAsyncTask extends AsyncTask<Void, Void, Void> {

        private TripDao tripDao;
        private Trip tripToDelete;

        public DeleteTripAsyncTask(TripDao tripDao, Trip tripToDelete) {
            this.tripDao = tripDao;
            this.tripToDelete = tripToDelete;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            if (tripToDelete != null) {
                tripDao.delete(tripToDelete);
            } else {
                tripDao.deleteAllTrips();
            }
            return null;
        }
    }

    // Method to update a trip in the database
    public void updateTrip(Trip trip) {
        new UpdateTripAsyncTask(tripDao).execute(trip);
    }

    // AsyncTask to update a trip in the database
    private static class UpdateTripAsyncTask extends AsyncTask<Trip, Void, Void> {
        private TripDao tripDao;

        public UpdateTripAsyncTask(TripDao tripDao) {
            this.tripDao = tripDao;
        }

        @Override
        protected Void doInBackground(Trip... trips) {
            tripDao.update(trips[0]);
            return null;
        }
    }
}
